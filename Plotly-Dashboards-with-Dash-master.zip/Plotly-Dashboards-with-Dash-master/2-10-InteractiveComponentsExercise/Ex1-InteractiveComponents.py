#######
# Objective: Create a dashboard that takes in two or more
# input values and returns their product as the output.
######

# Perform imports here:





# Launch the application:


# Create a Dash layout that contains input components
# and at least one output. Assign IDs to each component:











# Create a Dash callback:






# Add the server clause:
